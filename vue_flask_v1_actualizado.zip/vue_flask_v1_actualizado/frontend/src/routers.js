import { createRouter, createWebHistory } from "vue-router";
import HomePage from './components/HomePage'
import CategoriasPage from './components/CategoriasPage'
import DescuentoDiario from './components/DescuentoDiario'
import LoginPage from './components/LoginPage'


const routes = [
    {
        path: '/',
        name: 'home',
        component:HomePage
    },
    {
        path: '/categorias',
        name: 'categorias',
        component: CategoriasPage 
    },
    {
        path: '/descuento-diario',
        name: 'descuento-diario',
        component: DescuentoDiario 
    },
    {
        path: '/login',
        name: 'login',
        component: LoginPage 
    },

]

const router = createRouter({
    history:createWebHistory(),
    routes,
}) 

export default router;