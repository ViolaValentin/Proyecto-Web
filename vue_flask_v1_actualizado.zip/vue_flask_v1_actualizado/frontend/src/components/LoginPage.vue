<template>
  <div>

    <div class="cuadrante2">
        <div class="conteneor-form">    
            <form action="/login" method="post">
                <img class="profile-img" src="../assets/Diseño_sin_título__43_-removebg-preview.png" alt="">                            
                <p class="p-sign-in">Sign in</p>
                <p class="p-create-account">or <a href="../create-account">Create account</a></p>
                <input class="campos" type="text" name="username" placeholder="Nombre de usuario" required>
                <input class="campos" type="password" name="password" placeholder="Contraseña" required>
                <input class="boton" type="submit" value="Iniciar sesion">
            </form>
        </div>
    </div>
  </div>
</template>


<style>
*{
    margin: 0;
    padding: 0;
}
.cuadrante1{
    grid-column: 1/3;
    grid-row: 1/1;
    overflow: hidden;
}
.cuadrante2{
    grid-column: 2/4;
    grid-row: 1/1;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
}

.circulo-logo {
    height: 110vh;
    overflow: hidden;
}
.profile-img{
    width: 20vh;
    margin-left: 20vh;
}

.campos{
    width: 100%;
    padding: 2px;
    border-radius: 5vh;
    margin: 1vh;
    border: none;
    background-color: white;
    border: 2px solid #800080;
    padding: 2vh;
    font-size: 4vh;
    display: flex;
}
#formulario .campos-check{
    margin-left: 2vh;
    cursor: pointer;
    font-size: 10vh;
}
.boton{
    margin-left: 40vh;
    font-size: 3vh;
    background-color: #800080;
    border-radius: 5vh;
    border: 2px solid white;
    padding: 1vh;
    transition: 0.3s;
    color: white;
}
.boton:hover {
    background-color: white;
}

p{
    text-align: center;
    font-size: 3vh;
}
</style>