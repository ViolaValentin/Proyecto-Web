<template>
  <div>
    <h1>Descubrí nuestros descuentos</h1>
        <section class="contenedor-categorias">
            <div class="contenedor-cajas">
                <div><img src="https://www.cocinacaserayfacil.net/wp-content/uploads/2020/03/Platos-de-comida-que-pides-a-domicilio-y-puedes-hacer-en-casa-945x630.jpg" alt="" class="caja-categorias"><p class="p-categorias">#Comidas</p></div>
                <div><img src="https://concepto.de/wp-content/uploads/2014/08/tecnologia-e1551386720574-800x412.jpg" alt="" class="caja-categorias"><p class="p-categorias">#Tecnología</p></div>
                <div><img src="https://buenosaires.gob.ar/sites/default/files/styles/card_img_top/public/media/image/2020/11/20/7f211443570b111e8ebdc0bf97d42faf9e9c64e0.jpeg?itok=Nm8xEII6" alt="" class="caja-categorias"><p class="p-categorias">#Deportes</p></div>
                <div><img src="https://media.a24.com/p/89c392d0fcc296e390891e4c8d27beeb/adjuntos/296/imagenes/009/113/0009113226/1200x675/smart/pexels-photo-7991158jpeg.jpeg" alt="" class="caja-categorias"><p class="p-categorias">#Multimedia</p></div>
                <div><img src="https://media-cdn.tripadvisor.com/media/photo-s/16/1a/ea/54/hotel-presidente-4s.jpg" alt="" class="caja-categorias"><p class="p-categorias">#Hotelería</p></div>
                <div><img src="https://www.bbvaseguros.com.ar/wp-content/uploads/2021/09/img-mascotas.png" alt="" class="caja-categorias"><p class="p-categorias">#Mascotas</p></div>
                <div><img src="https://concepto.de/wp-content/uploads/2020/03/musica-e1584123209397.jpg" alt="" class="caja-categorias"><p class="p-categorias">#Música</p></div>
            </div>     
        </section>
        <section class="section-contenedor-imagenes-section-carrusel">
            <div class="contenedor-imagenes-section-carrusel">
                <div>
                    <img class="img1-section-carrusel" src="https://images.ecestaticos.com/j8exM3G00FKxNOsdok9_oL99m8Q=/0x0:2119x1415/1200x900/filters:fill(white):format(jpg)/f.elconfidencial.com%2Foriginal%2F21c%2F586%2F696%2F21c5866968158e56bf258a48a5e3053b.jpg" alt="">
                </div>
                <div>
                    <img class="img2-section-carrusel" src="https://cdn.computerhoy.com/sites/navi.axelspringer.es/public/media/image/2018/04/295717-que-es-malo-abusar-comida-rapida.png?tf=3840x" alt="">
                    <img class="img2-section-carrusel" src="https://www.cronista.com/files/image/304/304168/5ffe2013310ef_950_534!.png?s=8214844c5d8adf78f204ef924b8456dc&d=1633113288" alt="">
                </div>
            </div>
        </section>
          <section class="section-carrusel-descuentos">
        <div class="contenedor-carrusel-descuentos">
        <div class="carrusel-descuentos">
            <div class="descuento" v-for="descuento in descuentos" :key="descuento.idDescuento">
            <img class="img-descuento" :src="descuento.imagen" />
            <p>{{ descuento.nombre }}</p>
            <router-link :to="{ name: 'descuentoIndividual', params: { id: descuento.idDescuento } }">
                <button class="boton-descuento">Descuento</button>
            </router-link>
            </div>
        </div>
        </div>
        </section>
        <section class="section-ranking">
            <img class="imagen-fondo-ranking" src="../assets/vds.png" alt="">
            <div class="cuadro-ranking">
                <div class="encabezado-cuadro-ranking">
                    Ranking
                </div>
                <div class="cuerpo-cuadro-ranking">
                    <table>
                        <tbody>
                            <tr class="tr-ranking tr-encabezado">
                                <td>Usuario</td>
                                <td>Monto ahorrado</td>
                                <td>Beneficios aplicados</td>               
                            </tr>
                        <tr class="tr-ranking tr1">
                            <td>Mati</td>
                            <td>$30k</td>
                            <td>10</td>
                        </tr>
                        <tr class="tr-ranking tr2">
                            <td>Jero</td>
                            <td>$30k</td>
                            <td>10</td>
                        </tr>
                        <tr class="tr-ranking tr3">
                            <td>Valen</td>
                            <td>$30k</td>
                            <td>10</td>
                        </tr>
                        <tr class="tr-ranking">
                            <td>Fran</td>
                            <td>$30k</td>
                            <td>10</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      listaDescuentos: [],
    };
  },
  methods: {
    fetchProducts() {
      axios.get(`http://localhost:5000/`)
      .then((response) => {
        this.listaDescuentos = response.data.descuentos;
      })
      .catch((error) => {
        console.error("Error al obtener los productos:", error);
      });
    },
  },
  created() {
    this.fetchProducts();
  },
};

</script>

<style>

h1{
    text-align: center;
    margin-top: 4vh
}

.contenedor-imagenes-section-carrusel{
    display: flex;
    gap: 2vh;
    justify-content: center;
    align-items: center;
    padding: 2vh;
    flex-wrap: wrap;
}
.img1-section-carrusel{
    width: 70vh;
    height: 70vh;
    border-radius: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);

}
.img2-section-carrusel{
    width: 80vh;
    height: 33vh;
    margin-bottom: 2vh;
    border-radius: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);
}

.section-carrusel-descuentos{
    display: flex;
    justify-content: space-around;
}
.contenedor-carrusel-descuentos {
    overflow: hidden;
    position: relative;
    width: 100%;
}

.carrusel-descuentos {
    white-space: nowrap;
    transition: transform 1s;
    display: inline-block;
}

.descuento {
    display: inline-block;
    padding: 10px;
    box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);
    border-radius: 30px;
    margin: 15px;
    text-align: center;
}


.img-descuento{
    width: 200px;
    height: 120px;
    border-radius: 30px;
}
.boton-descuento{
    border-radius: 30px;
    background: linear-gradient(to bottom right, #4b0082, #800080);;
    border: none;
    color: white;
    padding: 1vh;
}

.section-ranking {
    margin-top: 10vh;
    display: flex;
    justify-content: center;
}

.cuadro-ranking{
    width: 75%;
    padding: 4vh;
}
.encabezado-cuadro-ranking{
    background: linear-gradient(to bottom right, #4b0082, #800080);;
    height: 10vh;
    border-top-left-radius: 30px;
    border-top-right-radius: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 4vh;
    color: white;
}
.cuerpo-cuadro-ranking{
    background-color: white;
    border-bottom-left-radius: 30px;
    border-bottom-right-radius: 30px;
    box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);
}
td{
    padding-right: 8vh;
    padding: 1vh;
    width: 33%;
}
.tr-ranking{
    display: flex;
    justify-content: center;
    padding: 1vh;
    margin: 0.5vh;
    gap: 1vh;
    border: 2px solid #4b0082;
    border-radius: 30px;
}
.tr-encabezado{
    background: linear-gradient(to bottom right, #4b0082, #800080);
    color: white;
}
.tr1{
    box-shadow: 6px 6px 2px 2px gold;
}
.tr2{
    box-shadow: 6px 6px 2px 2px silver;
}
.tr3{
    box-shadow: 6px 6px 2px 2px sienna;
}
tbody{
    width: 100%;
    display: flex;
    justify-content: space-around;
    flex-direction: column;
    padding: 1vh;
}
table{
    display: flex;
    justify-content: center;
    align-items: center;
}

.imagen-fondo-ranking{
    position: absolute;
    z-index: -1;
    height: 70vh;
    width: 100%;
}
</style>