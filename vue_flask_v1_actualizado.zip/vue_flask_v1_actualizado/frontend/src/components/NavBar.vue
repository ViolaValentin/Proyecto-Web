<template>
  <div>
    <section class="menu" v-if="$route.path !== '/login'">
    <section class="menu"> 
        <img src="" alt="" class="logo">
                    <img src="../assets/Diseño sin título (41).png" alt="" class="logo">
        <div class="contenedor-menues">
            <a class="menues" ><router-link  aria-current="page" to="/">Inicio</router-link></a>
            <a class="menues"><router-link  aria-current="page" to="/categorias">Categorias</router-link></a>
            <a class="menues"><router-link  aria-current="page" to="/descuento-diario">Descuento diario</router-link></a>         
        </div> 
        <div class="search-bar">
            <table class="search-bar-elements-container">
                <tr>
                    <td class="td-input-bar">
                        <input type="text" placeholder="Buscar..." class="search" id="inputSearch">
                    </td>
                    <td>
                        <a href="#" id="searchIcon"><img src="../assets/baseline_search_black_24dp.png" alt="" class="search-icon-img"></a>

                    </td>
                </tr>
            </table>
        </div>
    </section>
    </section>

  </div>
</template>
<script>
export default {

}
</script>

<style>
*{
    padding: 0;
    margin: 0;
    font-family: 'Fira Sans', sans-serif;
    font-family: 'Kanit', sans-serif;
}

.menu {
    width: 100%;
    height: 15vh;
    background: linear-gradient(to bottom right, #4b0082, #800080);
    border-bottom-left-radius: 6vh;
    border-bottom-right-radius: 6vh;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    justify-content: space-around;
    flex-wrap: wrap;
  }

.menues:hover{
    text-decoration: underline;
    color: white;
}


  .contenedor-categorias{
    display: flex;  
    flex-wrap: wrap;
    justify-content: center;
    overflow: hidden;
    width: 100%;

}
.contenedor-cajas{
    margin-top: 2vh;
    display: flex;
    width: 80%;
    justify-content: center;
    gap: 2vh;
    flex-wrap: wrap;
    margin-bottom: 5vh;
}
.p-categorias{
    position: absolute;
    margin-top: -7vh;
    margin-left: 3vh;
    color: white;
    font-size: 2.5vh;
    
}
.caja-categorias{
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    width: 20vh;
    height: 10vh;
    border-radius: 30px;
    filter: blur(1px);
    background: rgba(0, 0, 0, 15);

}

.contenedor-menues{
    gap: 1vh;
    display: flex;
    justify-content: space-around;
    margin-left: 1vh;
    }  
.logo{
    width: 20vh;
}
.menues{
    font-size: 3vh;
    font-weight: bold;
    color: white;
    text-decoration: none;

}
.search-bar{
    width: 40vh;
    height: 4vh;
    border-radius: 50px;
    display: flex;

}
.search-bar-elements-container{
    width: 100%;
    height: 100%;
    vertical-align: middle;

}
.td-input-bar{
    width: 100%;
}

.search{
    border: none;
    height: 100%;
    width: 100%;
    padding-right: 5vh;
    border-radius: 50px;
    font-size: 2vh;
    font-weight: 600;
    padding-left: 1vh;
    padding-top: 1vh;
    padding-bottom: 1vh;
}
.search-icon-img{
    margin-top: 1vh;
}

</style>